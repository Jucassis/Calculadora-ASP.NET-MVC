# Projeto Calculadora ASP.NET MVC

Projeto simples para realizar operações matemáticas básicas usando o padrão MVC.

## Como executar:
- Abra no Visual Studio
- Execute (IIS Express)
- Acesse a rota `/Calculadora/Index`