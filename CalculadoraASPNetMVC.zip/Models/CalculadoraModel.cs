namespace CalculadoraASPNetMVC.Models
{
    public class CalculadoraModel
    {
        public double Numero1 { get; set; }
        public double Numero2 { get; set; }
        public string Operacao { get; set; }
        public double Resultado { get; set; }
    }
}