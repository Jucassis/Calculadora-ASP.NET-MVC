using System.Web.Mvc;

namespace CalculadoraASPNetMVC.Controllers
{
    public class CalculadoraController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Calcular(double numero1, double numero2, string operacao)
        {
            double resultado = 0;

            switch (operacao)
            {
                case "Somar":
                    resultado = numero1 + numero2;
                    break;
                case "Subtrair":
                    resultado = numero1 - numero2;
                    break;
                case "Multiplicar":
                    resultado = numero1 * numero2;
                    break;
                case "Dividir":
                    if (numero2 != 0)
                        resultado = numero1 / numero2;
                    break;
            }

            ViewBag.Resultado = resultado;
            return View("Index");
        }
    }
}